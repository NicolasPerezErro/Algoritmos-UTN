#include <iostream>
#include <string.h>
using namespace std;

struct Nodo{
	int info;
	Nodo* sig;
};

struct planta {
	int piso;
	int suben;
	int bajan;
};

struct NodoAscensor {
	planta info;
	NodoAscensor* arriba;
	NodoAscensor* abajo;
};

struct pisoEliminado {
	int piso;
	int diffEntreSubenYBajan;	
};

struct Nota {
	int nota;
	Nota* sig;
};
struct infoestudiante {
	int id;
	Nota* notas[4];
};
struct Estudiante {
	infoestudiante infoEst;
	Estudiante* sigEst;
};
struct infocurso {
	int id;
	int promocionados;
	int regularizados;
	int recursantes;
	Estudiante* listaEstudiantes;
};
struct Curso {
	infocurso infoCur;
	Curso* sigCur;
};

struct novedad {
	int idCurso;
	int idEstudiante;
	int nroEvaluacion;
	int nota;
};

struct venta {
	int nroCliente;
	char articulo[50];
	int cant;
	float precioUnitario;
};

struct infoArt {
	char articulo[50];
	int cantidad;
	float precioUnitario;
};

struct Articulo {
	infoArt info;
	Articulo* sig;
};

struct infoCliente {
	int nroCliente;
	float dineroGastado;
	Articulo* articulosComprados;
};

struct Cliente {
	infoCliente info;
	Cliente* sig;
};


struct ingreso {
	int nroSocio;
	int nroSucursal;
	int estadia;
};

struct infoSocio {
	int nroSocio;
	int cantVisitas;
	int estadiaTotal;
};

struct Socio {
	infoSocio info;
	Socio* sig;
};

struct infoSuc {
	int nroSucusal;
	int cantPersonasDistintas;
	int cantVisitas;
	Socio* listaSocios;
};

struct Sucursal {
	infoSuc info;
	Sucursal* sig;
};

struct ventaAnual {
	int idMes;
	int idTicket;
	char descProducto[50];
	int cantVendida;
	float precioUnitario;
};

struct infoProducto {
	char descProducto[50];
	int cantVendida;
	float precioUnitario;
};

struct Producto {
	infoProducto info;
	Producto* sig;
};

struct infoTicket {
	int idTicket;
	Producto* productos;	
};

struct Ticket {
	infoTicket info;
	Ticket * sig;
};



//void burbuja(pelicula vec[], int len);
void agregarNodo(Nodo* &p, int x);
//void mostrar (Nodo* p);
void liberar(Nodo* &p);
Nodo* buscar(Nodo* p, int v);
void eliminar(Nodo*&p, int v);
int eliminarPrimerNodo(Nodo*&p);
Nodo* insertarOrdenado(Nodo* &p, int v);
void ordenar(Nodo*& p);
Nodo* buscaEInsertaOrdenado(Nodo* &p, int v, bool & enc);
void push(Nodo*& p, int v);
int pop(Nodo*& p);
void encolar(Nodo* & cFte, Nodo* & cFin, char v);
char desencolar(Nodo* &cFte, Nodo* & cFin);
void encolarUsandoLista(Nodo*& lista, int v);
int desencolarUsandoLista(Nodo*&lista);
void encolarUsandoArray(int vec[], int &len, int v);
int desencolarUsandoArray(int vec[], int &len);
void encolarUsandoPila(Nodo* &pila, int v);
int desencolarUsandoPila(Nodo* &pila);
//Devuelve distancia a la planta Baja
int insertarPisoArribaDelActualYMedir(NodoAscensor* &unNuevoPiso, NodoAscensor* &unPisoActual,
	int &distanciaPlantaAlta, int &distanciaPlantaBaja);
void medirDistanciaAPisosExtremos(NodoAscensor* unPiso, int &distanciaPlantaBaja, int &distanciaPlantaAlta);
void agregarNodoListaDoble(NodoAscensor* &lista, planta v);
int eliminarLosPisosPrimosArribaDe(NodoAscensor* &unPisoActual,FILE* arch);
bool esPrimo(int numero);
void eliminarPiso(NodoAscensor* &unPiso);
void procesarNovedades(FILE* novedades, Curso* &listaCursos);
void agregarNota(Curso* &listaCursos, int idCurso, int idEstudiante, int nroEvaluacion, int nota);
Curso* buscaEInsertaCurso(Curso* &p, infocurso v, bool & enc);
Curso* buscarCurso(Curso* p, infocurso v);
Curso* agregarCurso(Curso* &p, infocurso x);
Estudiante* buscaEInsertaEstudiante(Estudiante* &p, infoestudiante v, bool & enc);
Estudiante* buscarEstudiante(Estudiante* p, infoestudiante v);
Estudiante* agregarEstudiante(Estudiante* &p, infoestudiante x);
void agregarNota(Nota* &p, int x);
int getEstado(int notas[], int len);
void calcularEstadisticas(Curso* listaCursos);
//7-10 -> Ej 1
Cliente* buscaEInsertaCliente(Cliente* &p, infoCliente v, bool & enc);
Cliente* buscarCliente(Cliente* p, infoCliente v);
Cliente* agregarCliente(Cliente* &p, infoCliente x);

Articulo* buscaEInsertaArticulo(Articulo* &p, infoArt v, bool & enc);
Articulo* buscarArticulo(Articulo* p, infoArt v);
Articulo* agregarArticulo(Articulo* &p, infoArt x);

//7-10 -> Ej 2
Sucursal* buscaEInsertaSucursal(Sucursal* &p, infoSuc v, bool & enc);
Sucursal* buscarSucursal(Sucursal* p, infoSuc v);
Sucursal* agregarSucursal(Sucursal* &p, infoSuc x);

Socio* buscaEInsertaSocio(Socio* &p, infoSocio  v, bool & enc);
Socio* buscarSocio(Socio* p, infoSocio v);
Socio* agregarSocio(Socio* &p, infoSocio x);

//21-10 
Ticket* buscarEInsertaTicket(Ticket* &lista, infoTicket v, bool &enc);
Ticket* buscarTicket(Ticket* lista, infoTicket v);
Ticket* agregarTicketOrdenado(Ticket* &lista, infoTicket x);

Producto* agregarProducto(Producto* &lista, infoProducto x);

int main(int argc, char** argv) {
	
	Ticket * vecMes[12];
	
	for(int i=0; i < 12; i++) {
		vecMes[i] = NULL;
	}
	
	FILE * venta = fopen("ventas2018.dat","rb");
	ventaAnual reg;
	
	fread(&reg, sizeof(ventaAnual),1, venta);
	
	infoTicket infoT;
	infoProducto infoP;
	Ticket* ticketBuscado;
	bool enc;
	
	while(!feof(venta)) {
		
		infoT.idTicket = reg.idTicket;
		infoT.productos = NULL;
		ticketBuscado = buscarEInsertaTicket(vecMes[reg.idMes-1],infoT, enc);
		
		infoP.cantVendida = reg.cantVendida;
		infoP.precioUnitario = reg.precioUnitario;
		strcpy(infoP.descProducto, reg.descProducto);
		
		agregarProducto(ticketBuscado->info.productos,infoP);
		
		fread(&reg, sizeof(ventaAnual),1, venta);
	}

	fclose(venta);
	
	Ticket* auxT;
	Producto* auxP;
	float montoTotalItem;
	float montoTotalTicket;
	float ticketMayorMontoPorMes;
	int idTicketMayorMontoPorMes;
	float ticketMenorMontoPorMes;
	int idTicketMenorMontoPorMes;
	float importePromedioPorMes;
	int cantTicketPorMes;
	float montoTotalTicketPorMes;
	
	float ticketMayorMontoPorAnio = 0;
	int idMesMayorMontoPorAnio = 0;
	float ticketMenorMontoPorAnio = 99999999999999;
	int idMesMenorMontoPorAnio = 0;
	int cantTicketPorAnio = 0;
	float montoTotalTicketPorAnio = 0;
	int maxCantidadTicket = 0;
	int idMesMaxCantidadTicket =0;
	
	for(int i=0; i < 12; i++){
		cout << "Mes: " << i+1 << endl;
		ticketMayorMontoPorMes = 0;
		idTicketMayorMontoPorMes = 0;
		ticketMenorMontoPorMes = 999999999999999;
		idTicketMenorMontoPorMes = 0;
		importePromedioPorMes = 0;
		cantTicketPorMes = 0;
		montoTotalTicketPorMes = 0;
		auxT = vecMes[i];
		while(auxT != NULL) {
			cout << "Ticket: " << auxT->info.idTicket << endl;
			auxP = auxT->info.productos;
			montoTotalTicket = 0;
			while(auxP != NULL) {
				montoTotalItem = auxP->info.cantVendida * auxP->info.precioUnitario;
				cout << auxP->info.descProducto << " " << auxP->info.cantVendida << " unidades  $" << 
				auxP->info.precioUnitario << " pu  $" <<  montoTotalItem << " total" << endl;
				montoTotalTicket += montoTotalItem;
				auxP = auxP->sig;
			}
			montoTotalTicketPorMes += montoTotalTicket;
			cantTicketPorMes++;
			montoTotalTicketPorAnio += montoTotalTicket;
			cantTicketPorAnio++;
			cout << "Monto Total del Ticket $" << montoTotalTicket << endl;
			if(montoTotalTicket > ticketMayorMontoPorMes) {
				ticketMayorMontoPorMes = montoTotalTicket;
				idTicketMayorMontoPorMes = auxT->info.idTicket;
			}
			if(montoTotalTicket < ticketMenorMontoPorMes) {
				ticketMenorMontoPorMes = montoTotalTicket;
				idTicketMenorMontoPorMes = auxT->info.idTicket;
			}
			
			if(montoTotalTicket > ticketMayorMontoPorAnio) {
				ticketMayorMontoPorAnio = montoTotalTicket;
				idMesMayorMontoPorAnio = i+1;
			}
			if(montoTotalTicket < ticketMenorMontoPorAnio) {
				ticketMenorMontoPorAnio = montoTotalTicket;
				idMesMenorMontoPorAnio = i+1;
			}
				
			auxT = auxT->sig;
		}	
		
		if(cantTicketPorMes > maxCantidadTicket) {
			maxCantidadTicket = cantTicketPorMes;
			idMesMaxCantidadTicket = i+1;
		}
		
		cout << "El ticket de mayor monto fue " << idTicketMayorMontoPorMes << " con $" << ticketMayorMontoPorMes << endl;
		cout << "El ticket de menor monto fue " << idTicketMenorMontoPorMes << " con $" << ticketMenorMontoPorMes << endl;
		cout << "El ticket promedio fue $" << montoTotalTicketPorMes/cantTicketPorMes << endl; 
		
		cout << endl;
		cout <<"--------------------------------------------------------------" << endl;
		cout << endl;
	}
	
		cout << "El ticket de mayor monto del anio fue en el mes " << idMesMayorMontoPorAnio << " con $" << ticketMayorMontoPorAnio << endl;
		cout << "El ticket de menor monto del anio fue en el mes " << idMesMenorMontoPorAnio << " con $" << ticketMenorMontoPorAnio << endl;
		cout << "El ticket promedio del anio fue $" << montoTotalTicketPorAnio/cantTicketPorAnio << endl; 
		cout << "El mes con mas cantidad de tickets fue " << idMesMaxCantidadTicket << endl;
}

Producto* agregarProducto(Producto* &lista, infoProducto x) {
	Producto* nuevo = new Producto();
	nuevo->info = x;
	nuevo->sig = NULL;
	if(lista==NULL) { // la lista p esta vac�a
		lista = nuevo;
	} else {
		Producto* aux = lista;
		while(aux->sig != NULL) {
			aux = aux->sig;
		}
		aux->sig = nuevo;
	}
	
	return nuevo;
}

Ticket* buscarEInsertaTicket(Ticket* &lista, infoTicket v, bool &enc) {
	Ticket * nodoBuscado = buscarTicket(lista,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = agregarTicketOrdenado(lista,v);
		enc = false;
	}
	
	return nodoBuscado;
}
Ticket* buscarTicket(Ticket* lista, infoTicket v){
	Ticket* aux = lista;
	while(aux!= NULL && aux->info.idTicket != v.idTicket){
		aux = aux->sig;
	}
	return aux;
}
Ticket* agregarTicketOrdenado(Ticket* &lista, infoTicket x){
	Ticket* nuevo = new Ticket();
	nuevo->info = x;
	nuevo->sig = NULL;
	Ticket* ant = NULL;
	Ticket* aux = lista;
	
	while(aux!=NULL && aux->info.idTicket <= x.idTicket) {
		ant = aux;
		aux = aux->sig;
	}
	
	if(ant == NULL){ //Estoy insertando al principio
		lista= nuevo;		
	} else {
		ant->sig = nuevo;
	}
	nuevo->sig = aux;
	
	return nuevo;
}

Socio* buscarSocio(Socio* p, infoSocio v){
	Socio* aux = p;
	while(aux!= NULL && aux->info.nroSocio != v.nroSocio){
		aux = aux->sig;
	}
	return aux;
}

Socio* agregarSocio(Socio* &p, infoSocio x){
	Socio* nuevo = new Socio();
	nuevo->info = x;
	nuevo->sig = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Socio* aux = p;
		while(aux->sig != NULL) {
			aux = aux->sig;
		}
		aux->sig = nuevo;
	}
	
	return nuevo;
}

Socio* buscaEInsertaSocio(Socio* &p, infoSocio v, bool & enc) {
	Socio * nodoBuscado = buscarSocio(p,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = agregarSocio(p,v);
		enc = false;
	}
	
	return nodoBuscado;
}


Sucursal* buscarSucursal(Sucursal* p, infoSuc v){
	Sucursal* aux = p;
	while(aux!= NULL && aux->info.nroSucusal != v.nroSucusal){
		aux = aux->sig;
	}
	return aux;
}

Sucursal* agregarSucursal(Sucursal* &p, infoSuc x){
	Sucursal* nuevo = new Sucursal();
	nuevo->info = x;
	nuevo->sig = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Sucursal* aux = p;
		while(aux->sig != NULL) {
			aux = aux->sig;
		}
		aux->sig = nuevo;
	}
	
	return nuevo;
}

Sucursal* buscaEInsertaSucursal(Sucursal* &p, infoSuc v, bool & enc) {
	Sucursal * nodoBuscado = buscarSucursal(p,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = agregarSucursal(p,v);
		enc = false;
	}
	
	return nodoBuscado;
}



Articulo* buscarArticulo(Articulo* p, infoArt v){
	Articulo* aux = p;
	while(aux!= NULL && strcmp(aux->info.articulo,v.articulo) != 0){
		aux = aux->sig;
	}
	return aux;
}

Articulo* agregarArticulo(Articulo* &p, infoArt x){
	Articulo* nuevo = new Articulo();
	nuevo->info = x;
	nuevo->sig = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Articulo* aux = p;
		while(aux->sig != NULL) {
			aux = aux->sig;
		}
		aux->sig = nuevo;
	}
	
	return nuevo;
}

Articulo* buscaEInsertaArticulo(Articulo* &p, infoArt v, bool & enc) {
	Articulo * nodoBuscado = buscarArticulo(p,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = agregarArticulo(p,v);
		enc = false;
	}
	
	return nodoBuscado;
}


Cliente* buscarCliente(Cliente* p, infoCliente v){
	Cliente* aux = p;
	while(aux!= NULL && aux->info.nroCliente != v.nroCliente){
		aux = aux->sig;
	}
	return aux;
}

Cliente* agregarCliente(Cliente* &p, infoCliente x){
	Cliente* nuevo = new Cliente();
	nuevo->info = x;
	nuevo->sig = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Cliente* aux = p;
		while(aux->sig != NULL) {
			aux = aux->sig;
		}
		aux->sig = nuevo;
	}
	
	return nuevo;
}

Cliente* buscaEInsertaCliente(Cliente* &p, infoCliente v, bool & enc) {
	Cliente * nodoBuscado = buscarCliente(p,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = agregarCliente(p,v);
		enc = false;
	}
	
	return nodoBuscado;
}

void procesarNovedades(FILE* novedades, Curso* &listaCursos){
	 novedad reg;
	 
	 fread(&reg, sizeof(novedad),1,novedades);
	 
	 while(!feof(novedades)){
	 	 agregarNota(listaCursos, reg.idCurso, reg.idEstudiante, reg.nroEvaluacion, reg.nota);
		 fread(&reg, sizeof(novedad),1,novedades);
	 }
}

void agregarNota(Curso* &listaCursos, int idCurso, int idEstudiante, int nroEvaluacion, int nota) {
	  bool enc;
	  
	  infocurso datosCur;
	  datosCur.id = idCurso;
	  datosCur.promocionados = 0;
	  datosCur.recursantes = 0;
	  datosCur.regularizados = 0;
	  datosCur.listaEstudiantes = NULL;
	   
	  Curso* cursoDeInteres = buscaEInsertaCurso(listaCursos,datosCur,enc);
	  
	  infoestudiante datosEst;
	  datosEst.id = idEstudiante;
	  datosEst.notas[0] = NULL;
	  datosEst.notas[1] = NULL; 
	  datosEst.notas[2] = NULL; 
	  datosEst.notas[3] = NULL; 
	  
	  Estudiante* estudianteDeInteres = buscaEInsertaEstudiante(cursoDeInteres->infoCur.listaEstudiantes, datosEst, enc); 
	  
	  agregarNota(estudianteDeInteres->infoEst.notas[nroEvaluacion-1],nota);	  
}

void calcularEstadisticas(Curso* listaCursos){
	int ultimasNotas[4];
	Curso* auxCurso = listaCursos;
	int len = 4;
	int estadoEstudiante;
	
	while(auxCurso != NULL){
		Estudiante* auxEst = auxCurso->infoCur.listaEstudiantes;
		while(auxEst != NULL){
			
			/*Nota* aux1erEvaluacion = auxEst->infoEst.notas[0];
			while(aux1erEvaluacion->sig != NULL) {
				aux1erEvaluacion = aux1erEvaluacion->sig;
			}
			ultimasNotas[0] = aux1erEvaluacion->nota;
			
			Nota* aux2daEvaluacion = auxEst->infoEst.notas[1];
			while(aux2daEvaluacion->sig != NULL) {
				aux2daEvaluacion = aux2daEvaluacion->sig;
			}
			ultimasNotas[1] = aux2daEvaluacion->nota;
			
			Nota* aux3eraEvaluacion = auxEst->infoEst.notas[2];
			while(aux3eraEvaluacion->sig != NULL) {
				aux3eraEvaluacion = aux3eraEvaluacion->sig;
			}
			ultimasNotas[2] = aux3eraEvaluacion->nota;
			
			Nota* aux4taEvaluacion = auxEst->infoEst.notas[3];
			while(aux4taEvaluacion->sig != NULL) {
				aux4taEvaluacion = aux4taEvaluacion->sig;
			}
			ultimasNotas[3] = aux4taEvaluacion->nota;
			*/
			
			//Otra forma m�s corta
			for(int i =0; i < len; i++){
				Nota* notaEvaluacion = auxEst->infoEst.notas[i];
				while(notaEvaluacion->sig != NULL) {
					notaEvaluacion = notaEvaluacion->sig;
				}
				ultimasNotas[i] = notaEvaluacion->nota;
			}
			
			estadoEstudiante = getEstado(ultimasNotas,len);
			
			switch(estadoEstudiante){
				case 1:
					auxCurso->infoCur.promocionados++;
					break;
				case 2:
					auxCurso->infoCur.regularizados++;
					break;
				case 3:
					auxCurso->infoCur.recursantes++;
					break;
			}
			
			auxEst = auxEst->sigEst;
		}
		auxCurso = auxCurso->sigCur;
	}
	
	
}

//notas tiene la ultima nota de c/evaluacion
int getEstado(int notas[], int len){
	int estado;
	int promocion = 0;
	int recursa = 0;
	int regulariza = 0;
	
	for(int i = 0; i <len; i++){
		if(notas[i] < 6 ){
			recursa ++;
		} else if( notas[i] >= 6 && notas[i] < 8){
			regulariza++;
		} else {
			promocion++;
		}
	}
	
	if(promocion == 4){
		estado = 1;
	} else if(recursa >= 1){
		estado = 3;
	} else {
		estado = 2;
	}
	
	return estado;
}

void agregarNota(Nota* &p, int x) {
	Nota* nuevo = new Nota();
	nuevo->nota = x;
	nuevo->sig = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Nota* aux = p;
		while(aux->sig != NULL) {
			aux = aux->sig;
		}
		aux->sig = nuevo;
	}
}

Estudiante* buscaEInsertaEstudiante(Estudiante* &p, infoestudiante v, bool & enc){
	Estudiante * nodoBuscado = buscarEstudiante(p,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = agregarEstudiante(p,v);
		enc = false;
	}
	
	return nodoBuscado;
}

Estudiante* buscarEstudiante(Estudiante* p, infoestudiante v){
	Estudiante* aux = p;
	while(aux!= NULL && aux->infoEst.id != v.id){
		aux = aux->sigEst;
	}
	return aux;
}

Estudiante* agregarEstudiante(Estudiante* &p, infoestudiante x){
	Estudiante* nuevo = new Estudiante();
	nuevo->infoEst = x;
	nuevo->sigEst = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Estudiante* aux = p;
		while(aux->sigEst != NULL) {
			aux = aux->sigEst;
		}
		aux->sigEst = nuevo;
	}
	
	return nuevo;
}

Curso* buscaEInsertaCurso(Curso* &p, infocurso v, bool & enc){
	Curso * nodoBuscado = buscarCurso(p,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = agregarCurso(p,v);
		enc = false;
	}
	
	return nodoBuscado;
}

Curso* buscarCurso(Curso* p, infocurso v) {
	Curso* aux = p;
	while(aux!= NULL && aux->infoCur.id != v.id){
		aux = aux->sigCur;
	}
	return aux;
}

Curso* agregarCurso(Curso* &p, infocurso x){
	Curso* nuevo = new Curso();
	nuevo->infoCur = x;
	nuevo->sigCur = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Curso* aux = p;
		while(aux->sigCur != NULL) {
			aux = aux->sigCur;
		}
		aux->sigCur = nuevo;
	}
	
	return nuevo;
}



void eliminarPiso(NodoAscensor* &unPiso){
	
	if(unPiso->abajo){
		unPiso->abajo->arriba = unPiso->arriba;
	}
		
	if(unPiso->arriba != NULL){
		unPiso->arriba->abajo = unPiso->abajo;
	}
	
	delete(unPiso);
}

bool esPrimo(int numero){
	bool resultado = true;
	
	for(int i = 2; i < numero; i++){
		if(numero%i == 0){
			resultado = false;
			break;
		}
	}
	
	return resultado;
}

int eliminarLosPisosPrimosArribaDe(NodoAscensor* &unPisoActual,FILE* arch){
	int cantPisosEliminados = 0;
	pisoEliminado reg;
	
	NodoAscensor* aux = unPisoActual;
	aux = aux->arriba;
	while(aux != NULL){
		if(esPrimo(aux->info.piso)){
			reg.piso = aux->info.piso;
			reg.diffEntreSubenYBajan = aux->info.suben - aux->info.bajan;
			fwrite(&reg,sizeof(pisoEliminado),1,arch);
			eliminarPiso(aux);
			cantPisosEliminados++;
		}
		aux = aux->arriba;
	}
	
	return cantPisosEliminados;
}

void agregarNodoListaDoble(NodoAscensor* &lista, planta v) {
	NodoAscensor* nuevo = new NodoAscensor();
	nuevo->info = v;
	nuevo->arriba = NULL;
	nuevo->abajo = NULL;
	if(lista==NULL) { // la lista esta vac�a
		lista = nuevo;
	} else {
		NodoAscensor* aux = lista;
		while(aux->arriba != NULL) {
			aux = aux->arriba;
		}
		aux->arriba = nuevo;
		nuevo->abajo = aux;
	}
	
}

int insertarPisoArribaDelActualYMedir(NodoAscensor* &unNuevoPiso, NodoAscensor* &unPisoActual,
	int &distanciaPlantaMasAlta, int &distanciaPlantaMasBaja){
		unNuevoPiso->arriba = unPisoActual->arriba;
		unNuevoPiso->abajo = unPisoActual;
		unPisoActual->arriba->abajo = unNuevoPiso;
		unPisoActual->arriba = unNuevoPiso;
		
		medirDistanciaAPisosExtremos(unNuevoPiso,distanciaPlantaMasBaja,distanciaPlantaMasAlta);
		
		int distanciaPlantaBaja = 0;
		
		NodoAscensor* aux = unNuevoPiso;
		while(aux != NULL && aux->info.piso != 0){
			distanciaPlantaBaja++;
			if(aux->info.piso < 0) {
				aux = aux ->arriba;
			} else {
				aux = aux->abajo;
			}
		}
		
		return 	distanciaPlantaBaja;	
	}
	
void medirDistanciaAPisosExtremos(NodoAscensor* unPiso, int &distanciaPlantaMasBaja, int &distanciaPlantaMasAlta){
	distanciaPlantaMasBaja = 0;
	distanciaPlantaMasAlta = 0;
	
	cout << "Mas bajo" << endl;
	NodoAscensor* auxAbajo = unPiso->abajo;
	while(auxAbajo != NULL){
		cout << auxAbajo->info.piso << endl;
		distanciaPlantaMasBaja++;
		auxAbajo = auxAbajo->abajo;
	}
	
	cout << "Mas alto" << endl;
	NodoAscensor* auxArriba = unPiso->arriba;
	while(auxArriba != NULL){
		cout << auxArriba->info.piso << endl;
		distanciaPlantaMasAlta++;
		auxArriba = auxArriba->arriba;
	}
}

void encolarUsandoPila(Nodo* &pila, int v) {
	Nodo* pilaAux = NULL;
	
	while(pila != NULL){
		push(pilaAux, pop(pila));
	}
	
	push(pilaAux,v);
	
	while(pilaAux != NULL){
		push(pila,pop(pilaAux));
	}		   
}

int desencolarUsandoPila(Nodo* &pila) {
	return pop(pila);
}

void encolarUsandoArray(int vec[], int &len, int v){
	vec[len] = v;
	len++;
}

desencolarUsandoArray(int vec[], int &len){
	int resultado = vec[0];
	for(int i = 0; i < len; i++){
		vec[i] = vec[i+1];
	}
	len--;
	return resultado;	
}

void encolarUsandoLista(Nodo*& lista, int v){
     agregarNodo(lista,v);
}

int desencolarUsandoLista(Nodo*&lista) {
	return eliminarPrimerNodo(lista);
}

char desencolar(Nodo* &cFte, Nodo* & cFin){
	char retorno = cFte->info;
	Nodo* aux =  cFte;
	cFte = aux->sig;
	if(cFte == NULL) {
		cFin = NULL;
	}
	delete aux;
	return retorno;
}

void encolar(Nodo* & cFte, Nodo* & cFin, char v){
	Nodo * nuevo = new Nodo();
	nuevo->info = v;
	nuevo->sig = NULL;
	if(cFte == NULL) {
		cFte = nuevo;
	} else {
		cFin->sig = nuevo;	
	}
	cFin = nuevo;
}

int pop(Nodo*& p) {
	int retorno = p->info;
	Nodo* aux = p;
	p = aux->sig;
	delete aux;
	return retorno;
}

void push(Nodo*& p, int v){
	Nodo* nuevo = new Nodo();
	nuevo->info = v;
	nuevo->sig = p;
	p = nuevo;
}

/*Nodo* buscaEInsertaOrdenado(Nodo* &p, int v, bool & enc) {
	Nodo * nodoBuscado = buscar(p,v);
	if(nodoBuscado != NULL) { // el nodo est� en la lista
		enc = true;
	} else { // el nodo no est�
		nodoBuscado = insertarOrdenado(p,v);
		enc = false;
	}
	
	return nodoBuscado;
}*/

/*void ordenar(Nodo*& p) {
	Nodo* q = NULL;
	int valor;
	
	while(p != NULL) {
		valor = eliminarPrimerNodo(p);
		insertarOrdenado(q, valor);	
	}
	
	p = q;
}*/

Nodo* insertarOrdenado(Nodo* &p, int v){
	Nodo* nuevo = new Nodo();
	nuevo->info = v;
	nuevo->sig = NULL;
	Nodo* ant = NULL;
	Nodo* aux = p;
	
	while(aux!=NULL && aux->info <= v) {
		ant = aux;
		aux = aux->sig;
	}
	
	if(ant == NULL){ //Estoy insertando al principio
		p= nuevo;		
	} else {
		ant->sig = nuevo;
	}
	nuevo->sig = aux;
	
	return nuevo;
}

int eliminarPrimerNodo(Nodo* &p) {
	int retorno = p->info;
	Nodo* aux = p;
	p = p->sig;
	delete aux;
	return retorno;
}

void eliminar(Nodo*&p, int v) {
	Nodo* aux = p;
	Nodo* ant = NULL;
	while(aux!= NULL && aux->info != v){
		ant = aux;
		aux = aux->sig;
	}
	
	if(ant == NULL) { //Estamos eliminando el primer nodo
		p = aux->sig;
	} else {
		ant->sig = aux->sig;
	}
	
	delete aux;
}

Nodo* buscar(Nodo* p, int v) {
	Nodo* aux = p;
	while(aux!= NULL && aux->info != v){
		aux = aux->sig;
	}
	return aux;
}

void liberar(Nodo*&p){
	Nodo* aux;
	while(p!=NULL) {
		aux = p;
		p=p->sig;
		delete aux;
	}
}

/*void mostrar (NodoEstudiante* p) {
	NodoEstudiante* aux = p;
	while(aux != NULL) {
		cout << aux->info.legajo << endl;
		cout << aux->info.nya << endl;
		cout << aux->info.curso << endl;
		aux = aux->sig;
	}
}*/

void agregarNodo(Nodo* & p, int x) {
	Nodo* nuevo = new Nodo();
	nuevo->info = x;
	nuevo->sig = NULL;
	if(p==NULL) { // la lista p esta vac�a
		p = nuevo;
	} else {
		Nodo* aux = p;
		while(aux->sig != NULL) {
			aux = aux->sig;
		}
		aux->sig = nuevo;
	}
	
}

int busquedaBinaria(int vec[], int len, int valorBuscado){
	int pos = -1;
	int primero = 0; 
	int ultimo = len-1;
	int medio = (primero + ultimo) / 2;
	
	while(primero <= ultimo) {
		
		if(vec[medio] == valorBuscado) {
			pos = medio;
			break;
		} else if (vec[medio] < valorBuscado) {
			primero = medio + 1;
		} else {
			ultimo = medio - 1;
		}
		
		if(vec[primero] == valorBuscado) {
			pos = primero;
			break;
		}
		
		if(vec[ultimo] == valorBuscado){
			pos = ultimo;
			break;
		}
		
		medio = (primero + ultimo) / 2;
	}
	
	return pos;
}

/*void burbuja(pelicula vec[], int len) {
	pelicula temp;
	bool huboIntercambio = true;
	
	for(int i = 0; i < len && huboIntercambio; i++) {
		
		huboIntercambio = false;
		for(int j=0; j < len-1; j ++) {
			if(vec[j].cantEsp > vec[j+1].cantEsp) {
				huboIntercambio = true;
				temp = vec[j+1];
				vec[j+1] = vec[j];
				vec[j] = temp;
			}
		}
		
	}
	
}
*/

void insercion(int vec[], int len) {
	
	int elementoAInsertar, j; 
	
	for(int i = 1; i < len; i++) {
		
		elementoAInsertar = vec[i];	
		j = i - 1;
		
		while(j >= 0 && vec[j] > elementoAInsertar) {
			vec[j+1] = vec[j];
			j--;
		}
		vec[j+1] = 	elementoAInsertar;	
	}
}

void seleccion(int vec[], int len) {
	int indiceQueTieneElValorMinimo, temp;
	for(int i=0; i < len-1; i++){
		indiceQueTieneElValorMinimo = i;
		for(int j = i+1; j < len; j++) {
			if(vec[j] < vec[indiceQueTieneElValorMinimo]) {
				indiceQueTieneElValorMinimo = j;
			}
		}
		
		temp = vec[indiceQueTieneElValorMinimo];
		vec[indiceQueTieneElValorMinimo] = vec[i];
		vec[i] = temp;
	}
}
